#!/bin/bash
#
# Copyright 2013 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Command-line tool for interacting with Google Cloud Datastore.

set -o errexit

declare -r GCD="$0"
declare -r GCD_DIR=$(dirname "${GCD}")
declare -r DATASTORE_JAR="${GCD_DIR}/CloudDatastore.jar"
declare -r APPENGINE_TOOLS_JAR="${GCD_DIR}/.appengine/lib/appengine-tools-api.jar"
declare -r APPENGINE_API_STUBS_JAR="${GCD_DIR}/.appengine/lib/impl/appengine-api-stubs.jar"

if [[ ! ${JAVA} ]]; then
  JAVA="java"
fi

if [ ! -e "${DATASTORE_JAR}" ]; then
    echo "${DATASTORE_JAR} not found"
    exit 1
fi

if [ ! -e "${APPENGINE_TOOLS_JAR}" ]; then
    echo "${APPENGINE_TOOLS_JAR} not found"
    exit 1
fi

if [ ! -e "${APPENGINE_API_STUBS_JAR}" ]; then
    echo "${APPENGINE_API_STUBS_JAR} not found"
    exit 1
fi

${JAVA} -cp "${DATASTORE_JAR}:${APPENGINE_TOOLS_JAR}:${APPENGINE_API_STUBS_JAR}" \
    com.google.apphosting.client.datastoreservice.tools.CloudDatastore "${GCD}" "$@"
